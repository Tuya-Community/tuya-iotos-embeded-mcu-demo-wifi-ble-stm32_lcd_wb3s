#ifndef __MYOS_H
#define __MYOS_H

extern void System_Management(void);	//系统运行管理函数
extern void System_Run_2ms(void);		//2ms执行一次的程序
extern void Systen_Run_50ms(void);		//50ms执行一次的程序
extern void System_Run_500ms(void);	//500ms执行一次的程序	
extern void System_Run_1000ms(void);	//1000ms执行一次

#endif
